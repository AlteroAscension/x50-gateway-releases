#!/system/bin/sh

ui_print "- Installing X50 Gateway telemetry and control service"
ui_print "- Module path: $MODPATH"

# Do not invoke `magisk --sqlite` recursively from `magisk --install-module`.
# Several head-unit builds terminate the active installer with status 2 at
# that point. Zygisk is a global Magisk setting and must be managed in Magisk
# Manager before enabling the Gateway scope in LSPosed.
ui_print "- Zygisk must be enabled in Magisk Manager"

# Do not call Magisk permission helpers here. This head unit's Magisk build
# terminates the whole installer with status 2 from those helpers instead of
# returning control to customize.sh. A module service script must nevertheless
# be executable, so set that single bit with Android's plain chmod.
chmod 0755 "$MODPATH/service.sh"
ui_print "- Gateway module files prepared"
true
