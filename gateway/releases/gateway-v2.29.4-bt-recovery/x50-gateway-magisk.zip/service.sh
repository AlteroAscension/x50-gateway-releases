#!/system/bin/sh

until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 2
done

pm grant ru.lesnik.x50gateway android.car.permission.CAR_ENERGY >/dev/null 2>&1
pm grant ru.lesnik.x50gateway android.car.permission.CAR_ENGINE_DETAILED >/dev/null 2>&1
pm grant ru.lesnik.x50gateway android.car.permission.CAR_DIAGNOSTICS >/dev/null 2>&1
pm grant ru.lesnik.x50gateway android.permission.BLUETOOTH_PRIVILEGED >/dev/null 2>&1
am start-foreground-service -a ru.lesnik.x50gateway.START \
  -n ru.lesnik.x50gateway/.GatewayService >/dev/null 2>&1 \
  || am startservice -a ru.lesnik.x50gateway.START \
  -n ru.lesnik.x50gateway/.GatewayService >/dev/null 2>&1
